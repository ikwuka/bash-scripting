#!/bin/bash

echo "What more can I say than the fact 'I am having fun!'?"

echo "Do you agree?"

read mood

echo "You said" $mood. "Thank you for your response!!" 