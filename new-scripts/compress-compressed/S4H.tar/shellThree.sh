#!/bin/bash
greetingOne="thank you!"

greetingTwo="Thank you"

blessing="remain blessed!"

echo "Thank you for joining me."

echo "What else can I say than '$greetingOne'"

echo "From me from here ...:" $greetingTwo "and" $blessing