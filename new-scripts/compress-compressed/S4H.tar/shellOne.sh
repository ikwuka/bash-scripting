#!/bin/bash

echo "This is a new bash script."

echo "Created for fun sake, only!"